#!/bin/bash
# ----------------------------------------------------- 
# Wallpaper Script
# ----------------------------------------------------- 

pkill hyprpaper
sleep 1
hyprpaper -c ~/.config/hypr/hyprpaper.conf &
