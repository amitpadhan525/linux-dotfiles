---@diagnostic disable: undefined-global
hl.on("hyprland.start", function()
    hl.exec_cmd("/home/amit/.config/hypr/scripts/wallpaper.sh")
    hl.exec_cmd("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")
    hl.exec_cmd("xsettingsd")
    hl.exec_cmd("/usr/lib/polkit-kde-authentication-agent-1")
    hl.exec_cmd("gnome-keyring-daemon --start --components=secrets")
    hl.exec_cmd("/home/amit/.config/hypr/autostart.sh")
end)
