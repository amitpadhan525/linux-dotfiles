---@diagnostic disable: undefined-global
local mod = "SUPER"

hl.bind(mod .. " + E", hl.dsp.exec_cmd("thunar"))
hl.bind(mod .. " + RETURN", hl.dsp.exec_cmd("kitty --config ~/.config/kitty/kitty.conf"))
hl.bind(mod .. " + D", hl.dsp.exec_cmd("rofi -show drun -theme ~/.config/rofi/simple.rasi"))
hl.bind(mod .. " + W", hl.dsp.exec_cmd("pgrep waybar >/dev/null && pkill waybar || waybar &"))

hl.bind(mod .. " + N", hl.dsp.exec_cmd("bash -c 'pgrep hyprsunset && pkill hyprsunset || hyprsunset --temperature 4500'"))
hl.bind(mod .. " + S", hl.dsp.exec_cmd("~/.config/hypr/scripts/named_screenshot.sh"))
hl.bind(mod .. " + R", hl.dsp.exec_cmd("hyprctl reload"))
hl.bind(mod .. " + SHIFT + L", hl.dsp.exec_cmd("hyprlock"))

hl.bind(mod .. " + H", hl.dsp.exec_cmd("/home/amit/.config/hypr/scripts/snap.sh l"))
hl.bind(mod .. " + L", hl.dsp.exec_cmd("/home/amit/.config/hypr/scripts/snap.sh r"))
hl.bind(mod .. " + J", hl.dsp.exec_cmd("/home/amit/.config/hypr/scripts/snap.sh d"))
hl.bind(mod .. " + K", hl.dsp.exec_cmd("/home/amit/.config/hypr/scripts/snap.sh u"))

hl.bind(mod .. " + Q", hl.dsp.window.close())
hl.bind(mod .. " + F", hl.dsp.window.float({ action = "toggle" }))
hl.bind(mod .. " + SPACE", hl.dsp.exec_cmd("hyprctl dispatch fullscreen 1"))

for i = 1, 9 do
    hl.bind(mod .. " + " .. tostring(i), hl.dsp.focus({ workspace = i }))
    hl.bind(mod .. " + SHIFT + " .. tostring(i), hl.dsp.window.move({ workspace = i }))
end

hl.bind(mod .. " + mouse:272", hl.dsp.window.drag(), { mouse = true })
hl.bind(mod .. " + mouse:273", hl.dsp.window.resize(), { mouse = true })

hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd("pactl set-sink-volume @DEFAULT_SINK@ +5%"), { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd("pactl set-sink-volume @DEFAULT_SINK@ -5%"), { locked = true, repeating = true })
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("pactl set-sink-mute @DEFAULT_SINK@ toggle"), { locked = true, repeating = true })
hl.bind("XF86MonBrightnessUp", hl.dsp.exec_cmd("brightnessctl set +5%"), { locked = true, repeating = true })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd("brightnessctl set 5%-"), { locked = true, repeating = true })
