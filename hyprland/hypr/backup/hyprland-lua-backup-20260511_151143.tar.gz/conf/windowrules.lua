---@diagnostic disable: undefined-global
hl.window_rule({
    name = "float-specific-apps",
    match = { class = "^(pavucontrol|dialog|confirm|error|notification|splash|xdg-desktop-portal-gtk)$" },
    float = true,
    center = true,
})

hl.window_rule({
    name = "float-media-apps",
    match = { class = "^(?i)(mpv|feh|pqiv|sxiv|pavucontrol|blueman-manager)$" },
    float = true,
})

hl.window_rule({
    name = "center-media-apps",
    match = { class = "^(?i)(mpv|feh|pqiv|sxiv)$" },
    center = true,
})

hl.window_rule({
    name = "float-dialogs",
    match = { class = "^(?i)(.*dialog.*)$" },
    float = true,
    center = true,
})

hl.window_rule({
    name = "tile-all",
    match = { class = ".*" },
    float = false,
})

hl.window_rule({
    name = "float-workspace-7",
    match = { workspace = "7" },
    float = true,
})

hl.window_rule({
    name = "float-workspace-8",
    match = { workspace = "8" },
    float = true,
})

hl.window_rule({
    name = "float-workspace-9",
    match = { workspace = "9" },
    float = true,
})
